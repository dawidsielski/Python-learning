def multiplication(a, b):
    return a * b

def subtraction(a, b):
    return a - b

def power(a):
    return a**2