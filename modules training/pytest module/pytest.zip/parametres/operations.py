def multiplication(a, b):
    return a * b

def subtraction(a, b):
    return a - b

def power(a):
    return a**2

def last_list_element(L):
    return L[-1]